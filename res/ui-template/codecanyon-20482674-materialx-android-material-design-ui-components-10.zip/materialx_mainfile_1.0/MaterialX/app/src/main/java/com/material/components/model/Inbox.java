package com.material.components.model;

import android.graphics.drawable.Drawable;

public class Inbox {

    public int id;
    public Integer image = null;
    public Drawable imageDrw;
    public String from;
    public String email;
    public String message;
    public String date;
    public int color = -1;

}